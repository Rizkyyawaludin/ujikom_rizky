<?php
if (isset($_GET['url']))
{
    $url=$_GET['url'];

    switch($url)
    {
        case 'tulis_pengaduan';
        include 'tulis_pengaduan.php';
        break;

        case 'lihat_pengaduan';
        include 'lihat_pengaduan.php';
        break;

        case 'detail_pengaduan';
        include 'detail_pengaduan.php';
        break;

        case 'lihat_tanggapan';
        include 'lihat_tanggapan.php';
        break;
    }
}
else{
    ?>
    Selamat datang di aplikasi pengaduan masyarakat yang do buat untuk melaporkan pelanggaran atau penyimpangan kejadian-kejadian yang ada di msyarakat <br><br>
    Anda Login sebagai : <h2><b> <?php echo $_SESSION['nama']; 
    
}
?>