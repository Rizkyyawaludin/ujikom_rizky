<?php
require '../koneksi.php' ;
$id_tanggapan=$_GET['id_tanggapan'];

$sql=mysqli_query($koneksi, "DELETE from tanggapan WHERE id_tanggapan='$id_tanggapan' ");

if ($sql)
{
    ?>
    <script type="text/javascript">
        alert ('Data Berhasil Dihapus');
        window.location='admin.php?url=lihat_tanggapan';
    </script>
    <?php
}
?>